package com.distributedsystems.distributedsystems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DistributedSystemsApplicationTests {

	@Test
	void contextLoads() {
	}

}
